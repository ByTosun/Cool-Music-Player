package by.tsn.cmp.utils;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.database.Cursor;
import android.media.AudioAttributes;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.audiofx.Equalizer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.preference.PreferenceManager;
import android.provider.MediaStore;


import android.util.Log;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import com.squareup.otto.Bus;

import java.io.IOException;
import java.util.ArrayList;

import by.tsn.cmp.R;
import by.tsn.cmp.activities.MainActivity;
import by.tsn.cmp.eventBus.BusProvider;
import by.tsn.cmp.eventBus.Events;
import by.tsn.cmp.models.MusicModel;
import by.tsn.cmp.receivers.ControlActionsListener;

public class MusicService extends Service implements MediaPlayer.OnPreparedListener, MediaPlayer.OnErrorListener, MediaPlayer.OnCompletionListener, AudioManager.OnAudioFocusChangeListener {

    private AudioManager audioManager;
    private Object focusLock;
    boolean playbackDelayed = false;
    boolean playbackNowAuthorized = false;
    private boolean resumeOnFocusGain = false;
    private int result;
    private AudioAttributes audioAttributes;
    private static final int PROGRESS_UPDATE_INTERVAL = 1000;
    private static final int NOTIFICATION_ID = 55;
    public static Equalizer mEqualizer;
    private ArrayList<MusicModel> mSongs;
    private MediaPlayer mPlayer;
    private ArrayList<Integer> mPlayedSongIndexes;
    private MusicModel mCurrSong;
    private Bus mBus;
    private Handler mProgressHandler;
    private PendingIntent mPreviousIntent, mNextIntent, mPlayPauseIntent, mCloseIntent;
    private SharedPreferences sp;

    @Override
    public void onCreate() {
        super.onCreate();

        if (mBus == null) {
            mBus = BusProvider.getInstance();
            mBus.register(this);
        }

        sp = PreferenceManager.getDefaultSharedPreferences(this);
        mProgressHandler = new Handler();

        focusLock = new Object();
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        audioAttributes = new AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            AudioFocusRequest focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(audioAttributes).setAcceptsDelayedFocusGain(true).setOnAudioFocusChangeListener(this).build();

            int res = audioManager.requestAudioFocus(focusRequest);
            //noinspection SynchronizeOnNonFinalField
            synchronized(focusLock) {
                if (res == AudioManager.AUDIOFOCUS_REQUEST_FAILED) {
                    playbackNowAuthorized = false;
                } else if (res == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                    playbackNowAuthorized = true;
                } else if (res == AudioManager.AUDIOFOCUS_REQUEST_DELAYED) {
                    playbackDelayed = true;
                    playbackNowAuthorized = false;
                }
            }

        }else {

            result = audioManager.requestAudioFocus(afChangeListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }

        audioManager.registerAudioDeviceCallback(new adc(),null);

        setupService();
    }

    private class adc extends AudioDeviceCallback {

        @Override
        public void onAudioDevicesAdded(AudioDeviceInfo[] addedDevices) {
            super.onAudioDevicesAdded(addedDevices);
        }

        @Override
        public void onAudioDevicesRemoved(AudioDeviceInfo[] removedDevices) {
            super.onAudioDevicesRemoved(removedDevices);
            if(isPlaying()){
                pauseSong();
            }
        }

    }

    private void setupService() {
        mSongs = new ArrayList<>();
        mPlayedSongIndexes = new ArrayList<>();
        mCurrSong = null;

        setupIntents();
        loadAudioFiles();
        setupMediaPlayerIfNeeded();
        setupNotification();
    }

    private void setupIntents() {
        mPreviousIntent = getIntent(Constants.PREVIOUS);
        mNextIntent = getIntent(Constants.NEXT);
        mPlayPauseIntent = getIntent(Constants.PLAY_PAUSE);
        mCloseIntent = getIntent(Constants.CLOSE_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        final String action = intent.getAction();

        if (action != null) {

            switch (action) {

                case Constants.INIT:

                    if (mSongs == null){
                        setupService();
                    }

                    mBus.post(new Events.PlaylistUpdated(mSongs));
                    mBus.post(new Events.SongChanged(mCurrSong));
                    songStateChanged(isPlaying());
                    break;

                case Constants.PREVIOUS:
                    playPreviousSong();
                    break;

                case Constants.PLAY_PAUSE:
                    if (isPlaying()) {
                        pauseSong();
                    } else {
                        resumeSong();
                    }
                    break;

                case Constants.NEXT:
                    playNextSong();
                    break;

                case Constants.PLAY_POS:
                    playSong(intent);
                    break;

                case Constants.CLOSE_SERVICE:
                    mBus.post(new Events.ProgressUpdated(0));
                    destroyPlayer();
                    break;

                case Constants.SET_PROGRESS:

                    if (mPlayer != null) {
                        final int progress = intent.getIntExtra(Constants.PROGRESS, mPlayer.getCurrentPosition() / 1000);
                        mPlayer.seekTo(progress);
                        updateProgress(progress);
                    }
                    break;

                case Constants.RELOAD_LIST:
                    loadAudioFiles();
                    mBus.post(new Events.PlaylistUpdated(mSongs));
                    break;

                default:
                    break;
            }
        }

        return START_NOT_STICKY;
    }

    public void setupMediaPlayerIfNeeded() {

        if (mPlayer != null){
            return;
        }

        mPlayer = new MediaPlayer();
        mPlayer.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
        mPlayer.setAudioAttributes(audioAttributes);
        mPlayer.setOnPreparedListener(this);
        mPlayer.setOnCompletionListener(this);
        mPlayer.setOnErrorListener(this);
        setupEqualizer();
    }

    private void loadAudioFiles(){

        mSongs.clear();

        Uri collection;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
        } else {
            collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        }

        String[] projection = new String[] {
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.ALBUM_ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.DURATION
        };

        String order = MediaStore.Audio.Media.TITLE;

        try (Cursor cursor = getApplicationContext().getContentResolver().query(collection, projection, null, null, order)) {

            int idIndex = cursor.getColumnIndex(MediaStore.Audio.Media._ID);
            int album_idIndex = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID);
            int titleIndex = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
            int artistIndex = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
            int durationIndex = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
            int pathIndex = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);

            while (cursor.moveToNext()) {

                long id = cursor.getLong(idIndex);
                long album_id = cursor.getLong(album_idIndex);
                String title = cursor.getString(titleIndex);
                String artist = cursor.getString(artistIndex);
                String path = cursor.getString(pathIndex);
                int duration = cursor.getInt(durationIndex) / 1000;
                mSongs.add(new MusicModel(id, album_id, path, title, artist, duration));
            }

        }catch (Exception e){

            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
        }
    }


    private void setupEqualizer() {

        mEqualizer = new Equalizer(0, mPlayer.getAudioSessionId());

        if (sp.getBoolean("eq_switch", false)){

            mEqualizer.setEnabled(true);

            short[] r = mEqualizer.getBandLevelRange();
            int min_level = r[0];
            int max_level = r[1];

            mEqualizer.setBandLevel((short)0,(short)(min_level +(max_level - min_level)* sp.getInt("slider0",0) / 100));
            mEqualizer.setBandLevel((short)1,(short)(min_level +(max_level - min_level)* sp.getInt("slider1",0) / 100));
            mEqualizer.setBandLevel((short)2,(short)(min_level +(max_level - min_level)* sp.getInt("slider2",0) / 100));
            mEqualizer.setBandLevel((short)3,(short)(min_level +(max_level - min_level)* sp.getInt("slider3",0) / 100));
            mEqualizer .setBandLevel((short)4,(short)(min_level +(max_level - min_level)* sp.getInt("slider4",0) / 100));
        }
    }

    private void setupNotification() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            createChannel();
        }

        final String title = (mCurrSong == null) ? getString(R.string.choose_a_song) : mCurrSong.title;
        final String artist = (mCurrSong == null) ? getString(R.string.song_genre) : mCurrSong.artist;

        int playPauseIcon = R.drawable.img_play;

        if (isPlaying()) {
            playPauseIcon = R.drawable.img_pause;
        }

        final NotificationCompat.Builder notification = new NotificationCompat.Builder(this, "CMP").
                setStyle(new androidx.media.app.NotificationCompat.MediaStyle().setShowActionsInCompactView(0,1,2,3)).
                setShowWhen(false).
                setContentTitle(title).
                setContentText(artist).
                setSmallIcon(R.drawable.img_music).
                setVisibility(NotificationCompat.VISIBILITY_PUBLIC).
                setPriority(Notification.PRIORITY_DEFAULT).
                setContentIntent(getContentIntent()).
                setDeleteIntent(getDeleteIntent()).
                setOngoing(isPlaying()).
                addAction(R.drawable.img_before, getString(R.string.prev), mPreviousIntent).
                addAction(playPauseIcon, getString(R.string.play_pause), mPlayPauseIntent).
                addAction(R.drawable.img_next, getString(R.string.next), mNextIntent).
                addAction(R.drawable.img_close, getString(R.string.next), mCloseIntent);


        if (Build.VERSION.SDK_INT >= 31) {

            try {

                startForeground(NOTIFICATION_ID, notification.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);

            }catch (Exception e){

                Log.e("CMP_ERROR:",e.toString());
                destroyPlayer();
            }

        }else {

            startForeground(NOTIFICATION_ID, notification.build());
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void createChannel() {

        NotificationChannel channel = new NotificationChannel( "CMP", getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW);
        NotificationManager notificationManager = getSystemService(NotificationManager.class);

        if (notificationManager != null){
            notificationManager.createNotificationChannel(channel);
        }
    }

    private PendingIntent getContentIntent() {
        final Intent contentIntent = new Intent(this, MainActivity.class);
        return PendingIntent.getActivity(this, 0, contentIntent, PendingIntent.FLAG_IMMUTABLE);
    }

    private PendingIntent getDeleteIntent() {
        final Intent intent = new Intent(this, ControlActionsListener.class);
        intent.setAction(Constants.CLOSE_SERVICE);
        return PendingIntent.getBroadcast(getApplicationContext(), 0, intent, PendingIntent.FLAG_IMMUTABLE);
    }


    private PendingIntent getIntent(String action) {
        final Intent intent = new Intent(this, ControlActionsListener.class);
        intent.setAction(action);
        return PendingIntent.getBroadcast(getApplicationContext(), 0, intent, PendingIntent.FLAG_IMMUTABLE);
    }

    private int getNewSongId() {

        if (mPlayedSongIndexes.isEmpty()) {
            return 0;
        }

        final int lastIndex = mPlayedSongIndexes.get(mPlayedSongIndexes.size() - 1);
        return (lastIndex + 1) % mSongs.size();
    }

    public boolean isPlaying() {
        return mPlayer != null && mPlayer.isPlaying();
    }

    public void playPreviousSong() {

        if (mSongs.isEmpty()){
            return;
        }

        setupMediaPlayerIfNeeded();

        if (mPlayedSongIndexes.size() > 1 && mPlayer.getCurrentPosition() < 5000) {
            mPlayedSongIndexes.remove(mPlayedSongIndexes.size() - 1);
            setSong(mPlayedSongIndexes.get(mPlayedSongIndexes.size() - 1), false);
        } else {
            restartSong();
        }
    }

    public void pauseSong() {

        if (mSongs.isEmpty()){
            return;
        }

        setupMediaPlayerIfNeeded();

        mPlayer.pause();
        songStateChanged(false);
    }

    public void resumeSong() {
        if (mSongs.isEmpty()) {
            loadAudioFiles();
        }

        if (mSongs.isEmpty()){
            return;
        }

        setupMediaPlayerIfNeeded();

        if (mCurrSong == null) {
            playNextSong();
        } else {

            if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                mPlayer.start();
            }

            if (playbackNowAuthorized){
                mPlayer.start();
            }

        }

        songStateChanged(true);
    }

    public void playNextSong() {
        setSong(getNewSongId(), true);
    }

    private void restartSong() {
        mPlayer.seekTo(0);
        setupNotification();
    }

    private void playSong(Intent intent) {
        final int pos = intent.getIntExtra(Constants.SONG_POS, 0);
        setSong(pos, true);
    }

    public void setSong(int songIndex, boolean addNewSong) {

        if (mSongs.isEmpty()){
            return;
        }

        final boolean wasPlaying = isPlaying();
        setupMediaPlayerIfNeeded();

        mPlayer.reset();

        if (addNewSong) {

            mPlayedSongIndexes.add(songIndex);

            if (mPlayedSongIndexes.size() >= mSongs.size()) {
                mPlayedSongIndexes.clear();
            }
        }

        mCurrSong = mSongs.get(songIndex);

        try {

            final Uri trackUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, mCurrSong.id);
            mPlayer.setDataSource(getApplicationContext(), trackUri);
            mPlayer.prepareAsync();

            mBus.post(new Events.SongChanged(mCurrSong));

            if (!wasPlaying) {
                songStateChanged(true);
            }

        } catch (IOException e) {
            Log.e("CMP_ERROR:",e.toString());
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        if (sp.getBoolean("repeat", false)) {
            mPlayer.seekTo(0);

            if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                mPlayer.start();
            }

            if (playbackNowAuthorized){
                mPlayer.start();
            }

            setupNotification();
        } else if (mPlayer.getCurrentPosition() > 0) {
            mPlayer.reset();
            playNextSong();
        }
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        mPlayer.reset();
        playNextSong();
        return false;
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        mp.start();
        setupNotification();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        destroyPlayer();
    }

    private void destroyPlayer() {

        if (mPlayer != null) {

            if (isPlaying()){
                mPlayer.stop();
            }
            mPlayer.reset();
            mPlayer.release();
            mPlayer = null;

        }

        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            audioManager.abandonAudioFocus(afChangeListener);
        }

        if (mBus != null) {
            songStateChanged(false);
            mBus.post(new Events.SongChanged(null));
            mBus.unregister(this);
        }

        if (sp.getBoolean("eq_switch", false)){
            if (mEqualizer != null) {
                mEqualizer.release();
            }
        }

        stopForeground(true);
        stopSelf();
    }

    private void updateProgress(int progress) {
        mPlayer.seekTo(progress * 1000);
        resumeSong();
    }

    private void songStateChanged(boolean isPlaying) {
        handleProgressHandler(isPlaying);
        setupNotification();
        mBus.post(new Events.SongStateChanged(isPlaying));
    }

    private void handleProgressHandler(final boolean isPlaying) {

        if (isPlaying) {

            mProgressHandler.post(new Runnable() {
                @Override
                public void run() {
                    final int secs = mPlayer.getCurrentPosition() / 1000;
                    mBus.post(new Events.ProgressUpdated(secs));
                    mProgressHandler.removeCallbacksAndMessages(null);
                    mProgressHandler.postDelayed(this, PROGRESS_UPDATE_INTERVAL);
                }
            });

        } else {
            mProgressHandler.removeCallbacksAndMessages(null);
        }
    }

    // android 8 and later

    @SuppressWarnings("SynchronizeOnNonFinalField")
    @Override
    public void onAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_GAIN:
                if (playbackDelayed || resumeOnFocusGain) {
                    synchronized(focusLock) {
                        playbackDelayed = false;
                        resumeOnFocusGain = false;
                    }
                   if (!isPlaying()){
                       resumeSong();
                   }
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS:
                synchronized(focusLock) {
                    resumeOnFocusGain = false;
                    playbackDelayed = false;
                }
                if (isPlaying()){
                   pauseSong();
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                synchronized(focusLock) {
                    resumeOnFocusGain = isPlaying();
                    playbackDelayed = false;
                }
                if (isPlaying()){
                    pauseSong();
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                if (isPlaying()){
                    pauseSong();
                }
                break;
        }
    }

    // android 7 and below

    private final AudioManager.OnAudioFocusChangeListener afChangeListener = focusChange -> {
        if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
            if (isPlaying()){
                pauseSong();
            }
        } else if (focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            if (isPlaying()){
                pauseSong();
            }
        } else if (focusChange == AudioManager.AUDIOFOCUS_GAIN) {
            if (!isPlaying()){
                resumeSong();
            }
        }
    };

}
