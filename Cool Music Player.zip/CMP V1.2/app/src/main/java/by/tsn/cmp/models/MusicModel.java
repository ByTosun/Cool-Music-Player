package by.tsn.cmp.models;

public class MusicModel {

    public final long id;
    public final long album_id;

    public final String path;
    public final String title;
    public final String artist;
    public final int duration;
    public MusicModel(long i, long ai, String p, String title, String artist, int duration) {
        this.id = i;
        this.album_id = ai;
        this.path = p;
        this.title = title;
        this.artist = artist;
        this.duration = duration;
    }
}