package by.tsn.cmp.activities;

import android.content.SharedPreferences;

import android.media.audiofx.Equalizer;
import android.preference.PreferenceManager;
import android.os.Bundle;

import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;

import by.tsn.cmp.helpers.EqualizerView;
import by.tsn.cmp.utils.MusicService;
import by.tsn.cmp.R;

public class EqualizerActivity extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener {

    private SharedPreferences sp;
    private SharedPreferences.Editor et;
    private SwitchCompat enabled = null;
    private static Equalizer eq;
    private int min_level = 0;
    private int max_level = 100;
    private static final int MAX_SLIDERS = 5;
    private final SeekBar[] sliders = new SeekBar[MAX_SLIDERS];
    private final TextView[] slider_labels = new TextView[MAX_SLIDERS];
    private int num_sliders = 0;
    private EqualizerView equalizerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_equalizer);

        Toolbar toolbar = findViewById(R.id.toolbar_eq);
        setSupportActionBar(toolbar);

        toolbar.setNavigationOnClickListener(view -> finish());

        if (MusicService.mEqualizer != null) {

            equalizerView =  findViewById(R.id.equalizer_view);
            enabled = findViewById(R.id.switchEnable);

            sliders[0] = findViewById(R.id.mySeekBar0);
            slider_labels[0] = findViewById(R.id.centerFreq0);
            sliders[1] = findViewById(R.id.mySeekBar1);
            slider_labels[1] = findViewById(R.id.centerFreq1);
            sliders[2] = findViewById(R.id.mySeekBar2);
            slider_labels[2] = findViewById(R.id.centerFreq2);
            sliders[3] = findViewById(R.id.mySeekBar3);
            slider_labels[3] = findViewById(R.id.centerFreq3);
            sliders[4] = findViewById(R.id.mySeekBar4);
            slider_labels[4] = findViewById(R.id.centerFreq4);
            eq = MusicService.mEqualizer;

            num_sliders = eq.getNumberOfBands();
            short[] r = eq.getBandLevelRange();

            min_level = r[0];
            max_level = r[1];

            for (int i = 0; i < num_sliders && i < MAX_SLIDERS; i++) {
                int freq_range = eq.getCenterFreq((short)i);
                sliders[i].setOnSeekBarChangeListener(this);
                slider_labels[i].setText (milliHzToString(freq_range));
            }

            sp = PreferenceManager.getDefaultSharedPreferences(this);
            et = sp.edit();

            if(!sp.contains("setup")) {

                et.putBoolean("setup", true);
                et.putBoolean("eq_switch", false);

                et.putInt("slider0", 100 * eq.getBandLevel((short)0) / (max_level - min_level) + 50);
                et.putInt("slider1", 100 * eq.getBandLevel((short)1) / (max_level - min_level) + 50);
                et.putInt("slider2", 100 * eq.getBandLevel((short)2) / (max_level - min_level) + 50);
                et.putInt("slider3", 100 * eq.getBandLevel((short)3) / (max_level - min_level) + 50);
                et.putInt("slider4", 100 * eq.getBandLevel((short)4) / (max_level - min_level) + 50);
                et.apply();
            }

            equalizerView.stopBars();

            if (sp.getBoolean("eq_switch", false)){
                equalizerView.animateBars();
            }else {
                equalizerView.stopBars();
            }

            enabled.setChecked(sp.getBoolean("eq_switch", false));

            updateUI();

            enabled.setOnCheckedChangeListener((compoundButton, b) -> {

                if(enabled.isChecked()){
                    eq.setEnabled(true);
                    saveChanges();
                    for(int i=0;i<5;i++){
                        sliders[i].setEnabled(true);
                    }
                    equalizerView.animateBars();

                } else {

                    eq.setEnabled(false);
                    saveChanges();
                    for(int i=0;i<5;i++){
                        sliders[i].setEnabled(false);
                        
                    }
                    equalizerView.stopBars();
                }

            });

        }else {

            finish();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        equalizerView.stopBars();
    }

    public String milliHzToString (int milliHz) {

        if (milliHz < 1000){
            return "";
        }

        if (milliHz < 1000000){
            return "" + (milliHz / 1000) + "Hz";
        } else{
            return "" + (milliHz / 1000000) + "kHz";
        }
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int level, boolean b) {

        if (eq != null) {

            int new_level=min_level+(max_level-min_level)*level / 100;

            for (int i=0;i<num_sliders;i++) {
                if (sliders[i]==seekBar) {
                    eq.setBandLevel((short)i,(short)new_level);
                    saveChanges();
                    break;
                }
            }

        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {}

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {}

    public void updateUI(){

        applyChanges();

        if(enabled.isChecked()){
            for(int i=0;i<5;i++){
                sliders[i].setEnabled(true);
            }
            eq.setEnabled(true);
        } else{
            for(int i=0;i<5;i++){
                sliders[i].setEnabled(false);
            }
            eq.setEnabled(false);
        }

        updateSliders();
    }

    public void updateSliders () {

        for (int i = 0; i < num_sliders; i++) {
            int level;
            if (eq != null){
                level = eq.getBandLevel ((short)i);
            } else{
                level = 0;
            }
            int pos = 100 * level / (max_level - min_level) + 50;
            sliders[i].setProgress (pos);
        }
    }

    public void saveChanges(){
        et = sp.edit();

        et.putBoolean("setup", true);
        et.putBoolean("eq_switch", enabled.isChecked());

        et.putInt("slider0", 100 * eq.getBandLevel((short)0) / (max_level - min_level) + 50);
        et.putInt("slider1", 100 * eq.getBandLevel((short)1) / (max_level - min_level) + 50);
        et.putInt("slider2", 100 * eq.getBandLevel((short)2) / (max_level - min_level) + 50);
        et.putInt("slider3", 100 * eq.getBandLevel((short)3) / (max_level - min_level) + 50);
        et.putInt("slider4", 100 * eq.getBandLevel((short)4) / (max_level - min_level) + 50);
        et.apply();
    }

    public void applyChanges(){

        enabled.setChecked(sp.getBoolean("eq_switch",false));

        eq.setBandLevel((short)0,(short)(min_level+(max_level-min_level)* sp.getInt("slider0",0) / 100));
        eq.setBandLevel((short)1,(short)(min_level+(max_level-min_level)* sp.getInt("slider1",0) / 100));
        eq.setBandLevel((short)2,(short)(min_level+(max_level-min_level)* sp.getInt("slider2",0) / 100));
        eq.setBandLevel((short)3,(short)(min_level+(max_level-min_level)* sp.getInt("slider3",0) / 100));
        eq.setBandLevel((short)4,(short)(min_level+(max_level-min_level)* sp.getInt("slider4",0) / 100));
    }
}