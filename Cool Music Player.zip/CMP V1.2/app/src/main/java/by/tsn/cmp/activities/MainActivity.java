package by.tsn.cmp.activities;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.app.RecoverableSecurityException;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.format.Formatter;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.squareup.otto.Bus;
import com.squareup.otto.Subscribe;

import java.io.File;
import java.util.ArrayList;

import by.tsn.cmp.eventBus.BusProvider;
import by.tsn.cmp.eventBus.Events;
import by.tsn.cmp.utils.Constants;
import by.tsn.cmp.utils.MusicService;
import by.tsn.cmp.R;
import by.tsn.cmp.adapters.MusicAdapter;
import by.tsn.cmp.helpers.CmpHelper;
import by.tsn.cmp.models.MusicModel;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener,AdapterView.OnItemLongClickListener {

    private Toolbar toolbar;
    private static final int STORAGE_PERMISSION_CODE = 100;
    private static final int TIRAMISU_PERMISSION_CODE = 101;
    private static final int DELETE_PERMISSION_CODE = 102;
    private static final int NOTIFICATION_PERMISSION_CODE = 103;
    private SharedPreferences sp;
    private ImageView iv_play;
    private ImageView iv_eq;
    private ImageView iv_repeat;
    private ListView listView;
    private TextView tv_title;
    private TextView tv_artist;
    private SeekBar sb;
    private TextView tv_total;
    private TextView tv_current;
    private MusicAdapter musicAdapter;
    private Bus mBus;
    private ArrayList<MusicModel> arrayList;
    private Uri trackUri;
    private int pos;
    private boolean is_playing = false;
    private boolean mSeeking = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mBus = BusProvider.getInstance();
        mBus.register(this);
        sp = PreferenceManager.getDefaultSharedPreferences(this);
        trackUri = null;
        pos = 0;

        listView = findViewById(R.id.lv_songs);
        listView.setOnItemClickListener(this);
        listView.setOnItemLongClickListener(this);

        tv_total = findViewById(R.id.song_duration);
        tv_title = findViewById(R.id.songTitle);
        tv_title.setSelected(true);
        tv_artist = findViewById(R.id.songArtist);
        tv_current = findViewById(R.id.song_current_duration);
        sb = findViewById(R.id.progressbar);
        iv_repeat = findViewById(R.id.repeatBtn);
        iv_play = findViewById(R.id.playPauseBtn);
        iv_eq = findViewById(R.id.eqBtn);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

                final String duration = CmpHelper.getTimeString(sb.getMax());
                final String formattedProgress = CmpHelper.getTimeString(i);
                tv_total.setText(duration);
                tv_current.setText(formattedProgress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                mSeeking = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mSeeking = false;

                if (is_playing){
                    final Intent intent = new Intent(MainActivity.this, MusicService.class);
                    intent.putExtra(Constants.PROGRESS, seekBar.getProgress());
                    intent.setAction(Constants.SET_PROGRESS);
                    startService(intent);
                }
            }
        });

        iv_play.setOnClickListener(view ->  CmpHelper.sendIntent(this, Constants.PLAY_PAUSE));
        findViewById(R.id.nextBtn).setOnClickListener(view -> CmpHelper.sendIntent(this, Constants.NEXT));
        findViewById(R.id.previousBtn).setOnClickListener(view -> CmpHelper.sendIntent(this, Constants.PREVIOUS));

        iv_repeat.setOnClickListener(view -> {

            sp.edit().putBoolean("repeat", !sp.getBoolean("repeat",false)).apply();

            if (sp.getBoolean("repeat",false)){

                Toast.makeText(this, getString(R.string.repeat_on), Toast.LENGTH_SHORT).show();

            }else {

                Toast.makeText(this, getString(R.string.repeat_off), Toast.LENGTH_SHORT).show();
            }

            onResume();
        });

        iv_eq.setOnClickListener(view ->{

            if(is_playing){

                startActivity(new Intent(MainActivity.this,EqualizerActivity.class));

            }else {

                AlertDialog.Builder builder = new AlertDialog.Builder(this);

                builder.setTitle(getString(R.string.equalizer));
                builder.setMessage(getString(R.string.eq_msg));
                builder.setCancelable(false);

                builder.setPositiveButton(R.string.ok, (dialog, id) -> dialog.dismiss());

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        if (checkPermission()){

            setup();

        }else {

            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setTitle(getString(R.string.app_name));
            builder.setMessage(getString(R.string.welcome_msg));
            builder.setCancelable(false);

            builder.setPositiveButton(R.string.ok, (dialog, id) -> {
                dialog.dismiss();
                requestPermission();
            });

            builder.setNegativeButton(R.string.exit, (dialog, id) -> finish());

            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }

    public boolean checkPermission(){

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU){

            return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED;

        } else{

            return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED;
        }
    }

    private void requestPermission(){

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU){

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_MEDIA_AUDIO}, TIRAMISU_PERMISSION_CODE);

        } else {

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == TIRAMISU_PERMISSION_CODE){

            if (grantResults.length > 0){

                boolean d = grantResults[0] == PackageManager.PERMISSION_GRANTED;

                if (d){

                    setup();

                }else {

                    showAlert();
                }

            }
        }

        if (requestCode == STORAGE_PERMISSION_CODE){

            if (grantResults.length > 0){

                boolean a = grantResults[0] == PackageManager.PERMISSION_GRANTED;

                if (a){

                    setup();

                } else{

                    showAlert();
                }
            }
        }

        if (requestCode == NOTIFICATION_PERMISSION_CODE){

            if (grantResults.length > 0){

                boolean c = grantResults[0] == PackageManager.PERMISSION_GRANTED;

                if (!c){

                    AlertDialog.Builder builder = new AlertDialog.Builder(this);

                    builder.setTitle(getString(R.string.app_name));
                    builder.setMessage(getString(R.string.notification_permission_err));
                    builder.setCancelable(false);

                    builder.setPositiveButton(R.string.ok, (dialog, id) -> {
                        dialog.dismiss();

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_PERMISSION_CODE);
                        }

                    });

                    builder.setNegativeButton(R.string.exit, (dialog, id) -> finish());

                    AlertDialog dialog = builder.create();
                    dialog.show();

                }

            }
        }

        if (requestCode == DELETE_PERMISSION_CODE){

            if (grantResults.length > 0){

                boolean b = grantResults[0] == PackageManager.PERMISSION_GRANTED;

                if (b){

                    delete(launcher, trackUri);

                }else {

                    Toast.makeText(this, getString(R.string.error_failed_to_delete_file), Toast.LENGTH_SHORT).show();
                }

            }
        }
    }

    private void showAlert(){

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setMessage(getString(R.string.please_check_permissions));
        builder.setCancelable(false);

        builder.setPositiveButton(R.string.ok, (dialog, id) -> {
            dialog.dismiss();
            requestPermission();
        });

        builder.setNegativeButton(R.string.exit, (dialog, id) -> finish());

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void setup(){

        toolbar.setSubtitle(getString(R.string.please_wait));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_PERMISSION_CODE);
        }

        MobileAds.initialize(this, initializationStatus -> Log.i("CMP ADS:",initializationStatus.toString()));
        AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        CmpHelper.sendIntent(this, Constants.INIT);
    }


    @Subscribe
    public void songChangedEvent(Events.SongChanged event) {

        final MusicModel am = event.getSong();

        if (am != null) {

            tv_title.setText(am.title);
            tv_artist.setText(am.artist);

            sb.setMax(am.duration);
            if (!mSeeking) {
                sb.setProgress(0);
            }

        } else {

            tv_title.setText(R.string.choose_a_song);
            tv_artist.setText(R.string.song_genre);
        }

        if (toolbar.hasExpandedActionView()){
            toolbar.collapseActionView();
        }
    }

    @Subscribe
    public void songStateChanged(Events.SongStateChanged event) {

        if (event.getIsPlaying()) {
            iv_play.setImageResource(R.drawable.img_pause);
            is_playing = true;
        } else {
            iv_play.setImageResource(R.drawable.img_play);
            is_playing = false;
        }
    }

    @Subscribe
    public void playlistUpdated(Events.PlaylistUpdated event) {

        toolbar.setSubtitle(null);

        if(event.getSongs().isEmpty()){

            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setMessage(getString(R.string.no_music_msg));
            builder.setCancelable(false);

            builder.setPositiveButton(R.string.exit, (dialog, id) -> {

                try {
                    CmpHelper.sendIntent(this, Constants.CLOSE_SERVICE);
                }catch (Exception e){
                    Log.e("CMP_CLOSE_SERVİCE_MAİN", e.getMessage());
                }

                finish();
            });

            AlertDialog dialog = builder.create();
            dialog.show();

        }else {
            musicAdapter = new MusicAdapter(this, event.getSongs());
            arrayList = event.getSongs();
            listView.setAdapter(musicAdapter);
        }
    }

    @Subscribe
    public void songChangedEvent(Events.ProgressUpdated event) {
        if (!mSeeking) {
            sb.setProgress(event.getProgress());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (sp.getBoolean("repeat",false)){
            iv_repeat.setImageResource(R.drawable.img_repeat_on);
        }else {
            iv_repeat.setImageResource(R.drawable.img_repeat_off);
        }

        if (sp.getBoolean("eq_switch",false)){
            iv_eq.setImageResource(R.drawable.eq_on);
        }else {
            iv_eq.setImageResource(R.drawable.eq_off);
        }

    }


    @Override
    protected void onDestroy() {
        mBus.unregister(this);
        super.onDestroy();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        final Intent intent = new Intent(this, MusicService.class);
        intent.putExtra(Constants.SONG_POS, position);
        intent.setAction(Constants.PLAY_POS);
        startService(intent);
    }

    private final ActivityResultLauncher<IntentSenderRequest> launcher = registerForActivityResult(new ActivityResultContracts.StartIntentSenderForResult(), result -> {
        if (result.getResultCode() == Activity.RESULT_OK) {
            musicAdapter.applyDelete(pos);
            Toast.makeText(this, getString(R.string.deleted), Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this, getString(R.string.error_failed_to_delete_file), Toast.LENGTH_SHORT).show();
        }
    });

    @Override
    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

        final MusicModel am = arrayList.get(i);
        trackUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, am.id);
        pos = i;
        final File file = new File(am.path);

        final String s = getString(R.string.file_location) + " " + am.path + "\n\n" + getString(R.string.duration) + " " + CmpHelper.getTimeString(am.duration)  + "\n\n" + getString(R.string.file_size) + " " + Formatter.formatShortFileSize(this, file.length()) ;

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle(am.title);
        builder.setMessage(s);

        builder.setPositiveButton( getString(R.string.make_ringtone), (dialog, which) -> {

            if (Settings.System.canWrite(getApplicationContext())){

                try {

                    RingtoneManager.setActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE, trackUri);
                    Toast.makeText(getApplicationContext(), getString(R.string.ringtone_set_successfully), Toast.LENGTH_SHORT).show();
                    dialog.dismiss();

                } catch (Exception e) {

                    dialog.dismiss();
                    Toast.makeText(getApplicationContext(), e + getString(R.string.not_set_ringtone), Toast.LENGTH_SHORT).show();
                }

            }else {

                AlertDialog.Builder b = new AlertDialog.Builder(this);

                b.setMessage(getString(R.string.permission_msg));

                b.setPositiveButton(R.string.ok, (a, id) -> {
                    final Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                });

                b.setNegativeButton(R.string.cancel, (a, id) -> dialog.dismiss());

                AlertDialog d = b.create();
                d.show();

            }

        });


        builder.setNeutralButton( getString(R.string.share_music), (dialog, which) -> {

            dialog.dismiss();

            try {

                final Intent intent = new Intent(Intent.ACTION_SEND);
                intent.putExtra(Intent.EXTRA_STREAM, trackUri);
                intent.setType("audio/*");
                startActivity(Intent.createChooser(intent, am.title));

            }catch (Exception e){
                Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
            }

        });


        builder.setNegativeButton( getString(R.string.delete), (dialog, which) -> {

            dialog.dismiss();

            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {

                if (PackageManager.PERMISSION_GRANTED == ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE)){

                    delete(launcher, trackUri);

                }else {

                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, DELETE_PERMISSION_CODE);
                }

            }else {

                delete(launcher, trackUri);

            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();

        return true;
    }


    public void delete(ActivityResultLauncher<IntentSenderRequest> launcher, Uri uri) {

        ContentResolver contentResolver = getContentResolver();

        try {

            contentResolver.delete(uri, null, null);
            musicAdapter.applyDelete(pos);
            Toast.makeText(this, getString(R.string.deleted), Toast.LENGTH_SHORT).show();

        } catch (SecurityException e) {

            PendingIntent pendingIntent = null;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {

                ArrayList<Uri> collection = new ArrayList<>();
                collection.add(uri);
                pendingIntent = MediaStore.createDeleteRequest(contentResolver, collection);

            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                if (e instanceof RecoverableSecurityException) {
                    RecoverableSecurityException exception = (RecoverableSecurityException) e;
                    pendingIntent = exception.getUserAction().getActionIntent();
                }
            }

            if (pendingIntent != null) {
                IntentSender sender = pendingIntent.getIntentSender();
                IntentSenderRequest request = new IntentSenderRequest.Builder(sender).build();
                launcher.launch(request);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);

        MenuItem searchItem = menu.findItem(R.id.menu_search);
        SearchView searchView = (SearchView) searchItem.getActionView();

        EditText editText = searchView.findViewById(androidx.appcompat.R.id.search_src_text);

        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;

        switch (nightModeFlags) {

            case Configuration.UI_MODE_NIGHT_YES:
                editText.setTextColor(ContextCompat.getColor(this,R.color.white));
                editText.setHintTextColor(ContextCompat.getColor(this,R.color.white));
                editText.setHintTextColor(ContextCompat.getColor(this,R.color.white));
                break;

            case Configuration.UI_MODE_NIGHT_NO:
            case Configuration.UI_MODE_NIGHT_UNDEFINED:
                editText.setTextColor(ContextCompat.getColor(this,R.color.black));
                editText.setHintTextColor(ContextCompat.getColor(this,R.color.black));
                editText.setHintTextColor(ContextCompat.getColor(this,R.color.black));
                break;
        }

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                if (musicAdapter != null){
                    musicAdapter.getFilter().filter(newText);
                }
                return false;
            }
        });

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem m) {

        if (m.getItemId() == R.id.menu_about) {

            AlertDialog.Builder builder1 = new AlertDialog.Builder(this);

            String versionName = getString(R.string.app_name) + " " + "1.2";

            builder1.setTitle(versionName);
            builder1.setMessage(getString(R.string.about_desc));

            builder1.setPositiveButton(getString(R.string.close), (dialog, which) -> dialog.dismiss());

            builder1.setNegativeButton(getString(R.string.github), (dialog, which) -> {
                dialog.dismiss();
                try {
                    Uri uri = Uri.parse(getString(R.string.github_url));
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                }catch (Exception e){
                    Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            });

            builder1.setNeutralButton(getString(R.string.gmail),(dialogInterface, i) -> {
                Intent a = new Intent(Intent.ACTION_SEND);
                a.setType("message/rfc822");
                a.putExtra(Intent.EXTRA_EMAIL  , new String[]{getString(R.string.gmail_url)});
                try {
                    startActivity(Intent.createChooser(a, getString(R.string.contact)));
                } catch (android.content.ActivityNotFoundException ex) {
                    Log.e("CMP_EMAIL", ex.toString());
                }
            });

            AlertDialog Alert1 = builder1.create();
            Alert1 .show();

            return true;
        }

        if (m.getItemId() == R.id.menu_refresh){
            toolbar.setSubtitle(getString(R.string.please_wait));
            CmpHelper.sendIntent(this,Constants.RELOAD_LIST);
        }

        return super.onOptionsItemSelected(m);
    }
}
