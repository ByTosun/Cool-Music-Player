package by.tsn.cmp.eventBus;

import java.util.ArrayList;

import by.tsn.cmp.models.MusicModel;

public class Events {

    public static class SongChanged {
        private static MusicModel mm;
        public SongChanged(MusicModel songModel) {
            mm = songModel;
        }
        public MusicModel getSong() {
            return mm;
        }
    }

    public static class SongStateChanged {
        private static boolean mIsPlaying;
        public SongStateChanged(boolean isPlaying) {
            mIsPlaying = isPlaying;
        }
        public boolean getIsPlaying() {
            return mIsPlaying;
        }
    }

    public static class PlaylistUpdated {
        private static ArrayList<MusicModel> arrayList;
        public PlaylistUpdated(ArrayList<MusicModel> songModels) {
            arrayList = songModels;
        }
        public ArrayList<MusicModel> getSongs() {
            return arrayList;
        }
    }

    public static class ProgressUpdated {
        private static int mProgress;
        public ProgressUpdated(int progress) {
            mProgress = progress;
        }
        public int getProgress() {
            return mProgress;
        }
    }
}
