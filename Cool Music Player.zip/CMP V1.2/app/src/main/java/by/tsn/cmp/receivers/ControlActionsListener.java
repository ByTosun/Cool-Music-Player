package by.tsn.cmp.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import by.tsn.cmp.utils.Constants;
import by.tsn.cmp.helpers.CmpHelper;

public class ControlActionsListener extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        final String action = intent.getAction();

        switch (action) {
            case Constants.PREVIOUS:
            case Constants.PLAY_PAUSE:
            case Constants.NEXT:
            case Constants.CLOSE_SERVICE:
                CmpHelper.sendIntent(context, action);
                break;
            default:
                break;
        }
    }
}
