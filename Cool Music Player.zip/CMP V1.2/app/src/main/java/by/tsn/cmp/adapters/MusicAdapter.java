package by.tsn.cmp.adapters;

import android.annotation.SuppressLint;
import android.content.ContentUris;
import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import by.tsn.cmp.R;
import by.tsn.cmp.models.MusicModel;

public class MusicAdapter extends BaseAdapter implements Filterable {

    private final Context context;
    private final Uri uri;
    private final ArrayList<MusicModel> arrayList;
    private final ArrayList<MusicModel> arrayListFiltered;

    public MusicAdapter(Context context, ArrayList<MusicModel> arrayList) {
        this.context = context;
        this.uri = Uri.parse("content://media/external/audio/albumart/");
        this.arrayList = arrayList;
        this.arrayListFiltered = new ArrayList<>(arrayList);
    }

    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return arrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder;

        if (convertView == null) {

            convertView = LayoutInflater.from(context).inflate(R.layout.layout_music_item, parent, false);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);

        } else {

            viewHolder = (ViewHolder) convertView.getTag();
        }

        final MusicModel am = (MusicModel) getItem(position);
        final Uri albumArt = ContentUris.withAppendedId(uri, am.album_id);

        Picasso.get().load(albumArt).placeholder(R.drawable.img_loading).error(R.drawable.img_music).into(viewHolder.iv_album_art);
        viewHolder.tv_title.setText(am.title);
        viewHolder.tv_artist.setText(am.artist);

        return convertView;
    }

    private static class ViewHolder {
        final ImageView iv_album_art;
        final TextView tv_title;
        final TextView tv_artist;

        public ViewHolder(@NonNull View view) {
            iv_album_art =  view.findViewById(R.id.iv_album_art);
            tv_title = view.findViewById(R.id.tv_title);
            tv_artist = view.findViewById(R.id.tv_artist);
        }
    }

    public void applyDelete(int pos){
        arrayList.remove(pos);
        notifyDataSetChanged();
    }

    public Filter getFilter() {
        return exampleFilter;
    }

    private final Filter exampleFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            ArrayList<MusicModel> filteredList = new ArrayList<>();
            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(arrayListFiltered);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (MusicModel am : arrayListFiltered) {
                    if (am.title.toLowerCase().contains(filterPattern)|| am.artist.toLowerCase().contains(filterPattern)) {
                        filteredList.add(am);
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @SuppressWarnings("unchecked")
        @SuppressLint("NotifyDataSetChanged")
        @Override
        protected void publishResults(CharSequence charSequence, FilterResults results) {
            arrayList.clear();
            //noinspection rawtypes
            arrayList.addAll((List)results.values);
            notifyDataSetChanged();
        }
    };
}