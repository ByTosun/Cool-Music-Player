package by.tsn.cmp.utils;

public class Constants {
    private static final String PATH = "CMP.PATH";
    public static final String SONG_POS = "SONG_POS";
    public static final String PROGRESS = "PROGRESS";
    public static final String INIT = PATH + "INIT";
    public static final String PREVIOUS = PATH + "PREVIOUS";
    public static final String PLAY_PAUSE = PATH + "PLAY_PAUSE";
    public static final String NEXT = PATH + "NEXT";
    public static final String PLAY_POS = PATH + "PLAY_POS";
    public static final String CLOSE_SERVICE = "DELETE_NOTIFICATION";
    public static final String RELOAD_LIST = "REFRESH_LIST";
    public static final String SET_PROGRESS = PATH + "SET_PROGRESS";
}
